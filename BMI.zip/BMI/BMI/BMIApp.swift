//
//  BMIApp.swift
//  BMI
//
//  Created by D-MacBookPro13 on 2020/11/07.
//

import SwiftUI

@main
struct BMIApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
